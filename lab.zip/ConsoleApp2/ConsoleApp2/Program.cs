﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Женя"; // Определение переменной
            Console.WriteLine(name); // Инициализация

            name = "Женя ел много шоколада"; // Меняем значение переменной
            Console.WriteLine(name);

            Console.ReadKey();
        }
    }
}
