﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {

            TextReader tr = new StreamReader("note.txt");
            char[] line = tr.ReadLine().ToCharArray();
            int x, b;        
            for (int cs = 0; cs < line.Length; cs++)
            {
            
                if (line[cs] != ' ' && )
                {

                    Console.WriteLine("namber = {0:f0}", cs);

                }
            }
            tr.Close();
            Console.Read();
        }
    }
}
