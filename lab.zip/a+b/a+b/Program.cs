﻿using System;

namespace a_b
{
    class Program
    {
        static void Main()
        {

            int a, b;
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            Console.Write(a+b);
        }
    }
}
