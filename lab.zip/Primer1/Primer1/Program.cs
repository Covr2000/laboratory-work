﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primer1
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}*/

using System;
using System.Collections.Generic; 
using System.Text;

 
namespace MathTask
{
    class Program
    {
        #region Переменные круга
        private double r1;
        private double r2;
        private double s1;
        private double s2;
        private double s3; 
        #endregion 

        #region Переменные задачи о ладье 
        private byte x1;
        private byte y1;
        private byte x2;
        private byte y2;
        #endregion

        #region Переменные задачи о числе 
        private string value;
        private byte a;
        private byte b;  
        private byte c;
        private int result;
        #endregion

        static void Main(string[] args){
            Program ex = new Program();
            ex.ABD();
            ex.FirstTask();
            ex.SecondTask();
            ex.ThirdTask();
            Console.ReadLine();
        }
        private void ABD()
        {
            int a, b, c, x;
            Console.WriteLine("Введите трехзначное число:");

            x = int.Parse(Console.ReadLine());

            while (x >= 100 || x < 1000)
            {
                x = int.Parse(Console.ReadLine());
                Console.WriteLine("Ошибка: число не трехзначное!");
            }
       

            a = x % 10;
            b = x % 100 - a;
            c = x % 1000 - a - b;

            Console.WriteLine("\nТрехзначное число переведенное с права на лево {0}", a * 100 + b + c / 100);
            Console.Read();
        }

        private void FirstTask()
        {
            do {
                Console.WriteLine("Введите радиус 1-го круга:");
                this.r1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите радиус 2-го круга:");
                this.r2 = Convert.ToDouble(Console.ReadLine());
                if (r1 <= r2) {
                    Console.WriteLine("Радиус первого круга должен быть больше второго!");
                }
            } while (r1 <= r2);

            this.s1 = Math.PI * Math.Pow(r1, 2); this.s2 = Math.PI * Math.Pow(r2, 2);
            this.s3 = s1 - s2;

            Console.WriteLine("Площадь первого круга = {0}", s1);
            Console.WriteLine("Площадь второго круга = {0}", s2);
            Console.WriteLine("Площадь кольца между ними = {0}", s3);
        }

        private void SecondTask()
        {
            //Проверить может ли попасть ладья за один ход из поля заданного   
            //координатами x1,y1 в поле заданное координатами x2,y2   
            Console.WriteLine("Введите вертикаль на которой находится ладья):");
            this.x1 = Convert.ToByte(Console.ReadLine()); 


            Console.WriteLine("Введите горизонталь на которой находится ладья):");
            this.y1 = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Введите вертикаль поля на которое должна попасть ладья):");
            this.x2 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Введите горизонталь поля на которое должна попасть ладья):");
            this.y2 = Convert.ToByte(Console.ReadLine());

            if (x1 == x2 || y1 == y2) {
                Console.WriteLine("Данный ход ладьи возможен.");
            } else { Console.WriteLine("Данный ход ладьи невозможен!"); }
        }

        private void ThirdTask()
        {             //Дано трёхзначное число, найти сумму произведения его цифр
            do {
                Console.WriteLine("Введите число:");
                this.value = Console.ReadLine();
            } while (value.Length != 3); 

            this.a = byte.Parse(value[0].ToString());
            this.b = byte.Parse(value[1].ToString());
            this.c = byte.Parse(value[2].ToString());
            this.result = (a * b) + (a * c) + (b * c);

            Console.WriteLine("Сумма произведения трёх цифр:{0}", this.result);
        }
    }
}
