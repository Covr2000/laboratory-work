﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_2
{
    class Program
    {
        static void Main(string[] args)
        {

            double y, x;
            int N;
            x = double.Parse(Console.ReadLine());
            y = double.Parse(Console.ReadLine());
            double Y = 1 - x * x;
            if (Y > y && x < 0) { N = 1; }
            if (Y < y && x > 0) { N = 2; }
            N = (x > 0 && y > 0) ? 3 : (x < 0  && y > 0) ? 4 : (x < 0 && y < 0) ? 3 : 0;
            Console.WriteLine(N);
            Console.Read();

        }
    }
}























