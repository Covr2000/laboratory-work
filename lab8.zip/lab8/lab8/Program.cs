﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    class Program
    {
            static void p11(double x)
            {

                x = (x >= 0) ? Math.Pow(x, 2) : Math.Pow(x, 3);

                Console.WriteLine(x);

            }

            static void Main()

            {

                for (double AX = -10; AX <= 10; ++AX)
                {

                    p11(AX);

                }
            Console.Read();
        }

    }
}
