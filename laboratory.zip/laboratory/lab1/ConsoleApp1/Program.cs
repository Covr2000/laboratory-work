﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            Console.WriteLine("Ведите значение Х ");
            x = Double.Parse(Console.ReadLine());
            y = (Math.Abs(x) + Math.Pow(Math.Sin(x), 2) - 3) / (5 * Math.Pow(x, 3));
            Console.WriteLine("y={0:f8} ",y);
            Console.Read();
            
        }
    }
}
