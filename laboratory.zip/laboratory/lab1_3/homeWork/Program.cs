﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("T = tg(x)^1/2+2*cos(a*x)-x^1/2");
            double x, a, t;
            Console.Write("Введите значение x: ");
            x = double.Parse(Console.ReadLine());
            Console.Write("Введите значение a: ");
            a = double.Parse(Console.ReadLine());
            t = (Math.Pow(Math.Tan(x),1/2) + 2*Math.Cos(a*x) - Math.Pow(x,1/2));
            Console.WriteLine("y={0:f8} ", t);
            Console.Read();
        }
    }
}
