﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            double A, B;
            Console.WriteLine("3.Даны два целых числа: A, B. Проверить истинность высказывания: «Числа A и B имеют одинаковую четность».");
            Console.Write("Введите A:");
            A = double.Parse(Console.ReadLine());

            Console.Write("Введите B:");
            B = double.Parse(Console.ReadLine());
            if ((A % 2 == 0) && (B % 2 == 0))
            {
                Console.WriteLine("ЧЕТНЫЕ", A);
            }
            else
            {
                Console.WriteLine("НЕЧЕТНЫЕ");
            }
            Console.ReadKey();
        }
    }
}
