﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_3_1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double Z, y = 4, x, P;

            x = double.Parse(Console.ReadLine());
            P = 1;
            for (int m = 1; m <= 5; m++)
            {
                P = P * m;
            }
            Console.WriteLine("Z = {0}", Math.Pow(y,3) + Math.Pow(P, 3) );
            Console.ReadKey();

        }
    }
}
