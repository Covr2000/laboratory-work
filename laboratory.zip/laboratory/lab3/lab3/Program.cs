﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            double y, x, sum;
            int n;
            x = double.Parse(Console.ReadLine());
            sum = 0;
            for(n= 1; n <= 10; n++)
            {
                y = sum = sum + n * n;
            }
            y = sum + Math.Sin(x) / (x + 2);
            Console.WriteLine("y = {0}", y);
            Console.ReadKey();
        }
    }
}
