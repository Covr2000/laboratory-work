﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace li2
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader failR = new StreamReader("LAB2.TXT");
            StreamWriter failW = new StreamWriter("LAB2R.TXT");
            double z, y, x, a = 1.7;
            failW.WriteLine("+-----------------------------------------+");
            failW.WriteLine("+       Аргумент         +     Функция    +");
            failW.WriteLine("+ ----------------------------------------+");
            
            for (int AX = 0; AX < 8; ++AX)
            {
                y = double.Parse(failR.ReadLine());
                x = double.Parse(failR.ReadLine());
                

                    z = a * Math.Pow((x * y), 0.7) * Math.Cos(a * x);
                    if(z > 0)
                        failW.WriteLine("+    X = {0,0:f2}            +    {1,0:f8}  +", x, z);
                    if (z < 0)
                        failW.WriteLine("+    X = {0,0:f2}            +    {1,0:f7}  +", x, z);
            }
            failW.WriteLine("+-----------------------------------------+");
            failR.Close();
            failW.Close();
        }
    }
}
