﻿// using systen LDE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rar
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Y = sin|x|^3 + 2*x^1/2 + 2bx");
            double x, b, y;
            Console.Write("Введите значение x: ");
            x = double.Parse(Console.ReadLine());
            Console.Write("Введите значение a: ");
            b = double.Parse(Console.ReadLine());
            y = Math.Pow(Math.Sin(x), 3) + 2 * Math.Pow(x, 2) + 2 *b*x;
            Console.WriteLine("y={0:f8} ", y);
            Console.Read();
        }
    }
}
