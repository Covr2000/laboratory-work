﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double d, x, y, s, a, p, sl, sd;
            int n, k;
            Console.WriteLine('^' + "Промежуточный результаты" + '\n');
            x = 10;
            k = 0;
            s = 0;
            p = 1;
            n = 2;
            a = x * x;
            do
            {
                d = a;
                s += a;
                sl = Math.Pow(-1, n - 1) * Math.Pow(2, 2 * n - 1) * Math.Pow(x, 2 * n);
                for(int i = 1; i <= 2 * n; ++i)
                {
                    p = p * i;
                }
                sd = p;
                a = sl / sd;
                n++;
                k++;
                p = 1;
                Console.WriteLine('\t' + "Интерация №" + k +'\n' + "a=" + a +"S=" +s +'\n');

            }  while (Math.Abs(d - a) >= 0.000001);
            y = Math.Sin(x) * Math.Sin(x);
            Console.WriteLine(" Результаты: \n Cумма S={0:6} \n \t Функции SIN(X)^2={2:f6} \n Количество рядов: К={1}", s,k,y);
            Console.ReadKey();
        }
    }
}
