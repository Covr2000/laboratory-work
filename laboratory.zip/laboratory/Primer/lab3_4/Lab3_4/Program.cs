﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 0.5;
            int m = 2;
            double S = 0, STEP;
            for(int i = 1; i <=2*m-1; i++)
            {
                STEP = Math.Pow( x, 2 * i - 1);
                S = S + (STEP / (2 * i - 1));
            }
            double OUTPUT = Math.Abs(2 * S - Math.Log((1 + x) / (1 - x)));
            Console.WriteLine("OUTPUT: {0:f21}", OUTPUT);
            Console.ReadKey();

        }
    }
}
