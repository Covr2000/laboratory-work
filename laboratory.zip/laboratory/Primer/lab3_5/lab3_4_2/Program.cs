﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3_4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 3;
            int n = 4;
            double S = 0, STEP, PN;
            int fct = 1;
            for (int i = 1; i <=  n; i++)
            {
                PN = Math.Pow(-1, i);
                STEP = Math.Pow(3, 2 * i) * Math.Pow(x, 2 * i + 1);
                for (int f = 1; f <= i; f++)
                {
                    fct = 2 * fct * f;
                }
                S =  S + PN*STEP/fct;

            }

            double OUTPUT = Math.Abs( S-x*Math.Cos(x*3) );
            Console.WriteLine("OUTPUT: {0:f21}", OUTPUT);
            Console.ReadKey();
        }
    }
}
