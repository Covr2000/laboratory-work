﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program ex = new Program();
            ex.ABD();
        }

        private void ABD()
        {
            int a, b, c ,x;
            Console.WriteLine("Введите x:");
            x = int.Parse(Console.ReadLine());
            a = x % 10;
            Console.WriteLine(a);
            b = x % 100 - a;
            Console.WriteLine(b);
            c = x % 1000 - a - b;
            Console.WriteLine(c + "\n");

            Console.WriteLine(x = a * 100 + b + c / 100);
            Console.Read();
        }
    }
}
