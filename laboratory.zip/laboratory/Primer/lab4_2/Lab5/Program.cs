﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter f = new StreamWriter("ddd.txt");
            // StreamReader failR = new StreamReader("1e.txt");
            f.WriteLine("gsgsgsdgsdgsdg");
            f.Close();
           // Console.ReadKey();
        }
    }
}
