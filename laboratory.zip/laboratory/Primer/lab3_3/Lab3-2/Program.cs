﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double y, x, P;
            int n;
            x = double.Parse(Console.ReadLine());
            P = 0;
            for (n = 1; n <= 10; n++)
            {
                P = P * (n * n);
            }
            y = P + Math.Sin(x) / (x + 2);
            Console.WriteLine("y = {0:f8}", y);
            Console.ReadKey();

        }
    }
}
