﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            double F, x, y, z, max, min;
            x = double.Parse(Console.ReadLine());
            y = double.Parse(Console.ReadLine());
            z = double.Parse(Console.ReadLine());

            min = (x > y + z)? y + z : x;
            max = (x > y) ? x : y;
            F = min / max + Math.Sin(z);

    

            Console.WriteLine("{0:f8}", F);
            Console.Read();
        }
    }
}
