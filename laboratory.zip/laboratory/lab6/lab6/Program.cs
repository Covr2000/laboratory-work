﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter p = new StreamWriter("rez.txt");
            float a, x, y;
            p.WriteLine("РЕЗУЛЬТАТЫ РАСЧЁТА");
            for (a = 1; a <= 2; a += 0.5f)
            {
                p.WriteLine(" a=" + a);
                for (x = 1; x <= 7; x += 0.25f)
                {
                    y = (float)(a * Math.Cos(x) / Math.Sqrt(1 + a * x * x));
                    p.WriteLine(" x=" + x + "/t" +" y= " + y);
                }
            }
            p.Close();
        }
    }
}
