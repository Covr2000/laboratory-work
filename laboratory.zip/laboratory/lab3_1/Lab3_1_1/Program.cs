﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double y, x, sum;
            
            x = double.Parse(Console.ReadLine());
            sum = 0;
            for (int i = 1; i <= 5; i++)
            {
                sum =  sum + i;
            }
            y = ( Math.Sin(sum*x) + (x * x) ) / (x * x * x * x + 2);
            Console.WriteLine("y = {0}", y);
            Console.ReadKey();

        }
    }
}
