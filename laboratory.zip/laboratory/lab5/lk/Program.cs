﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader failR = new StreamReader("in.txt");
            StreamWriter failW = new StreamWriter("out.txt");
            int A = int.Parse(failR.ReadLine());
            byte I = byte.Parse(failR.ReadLine());
            double C = double.Parse(failR.ReadLine());
            bool L = Convert.ToBoolean(failR.ReadLine());
            string name = failR.ReadLine();
            failW.WriteLine("A = {0,2}", A);
            failW.WriteLine("I = {0}", I);
            failW.WriteLine("C = {0,8:f5}", C);
            failW.WriteLine("L = {0}", L);
            failW.WriteLine("Name = {0}", name);
            failR.Close();
            failW.Close();
        }
    }
}
