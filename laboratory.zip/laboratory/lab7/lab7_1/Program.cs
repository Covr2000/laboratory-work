﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7_1
{
  
        class Test
        {
            public int a = 1;
            public const double c = 2.3;
            public static string s = "Test";
            double y;
        }

       class Program
       {
            public static string prg_s = "Program";
            public static float prg_c = (float)3.3;
            static void Main(string[] args)
            {
                Test x = new Test();

                Console.WriteLine(x.a);
                Console.WriteLine(Test.c);

                Console.WriteLine(Test.s);
                
                Console.WriteLine(prg_s);
                Console.WriteLine(prg_c);
            }
        }
       
    }
}
